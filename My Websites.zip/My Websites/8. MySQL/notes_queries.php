<?php

	/* Connect to mysql:
	
	mysqli_connect("server[local host if it's on the same server or the server ip address]", "Username", "password", "name of database"); 
	
	*/
	$link = mysqli_connect("localhost", "cl57-example69", "RH/w9C2G-", "cl57-example69");
	
	/* Test if MySQL is working
	
	echo "working!";
	
	Check if you bugged it out:
	
	echo mysqli_connect_error();
	
	*/
	
	//let user know if there is a bad database connection --->
	if (mysqli_connect_error()) {
		// die vs echo: die doesn't let the code load at all if mySQL wont work!
		die("Could not connect to database");
	}
	
	// How to insert data into database tables --->
	// Sometimes you should use a "back-tick"(``) to surround field names if it doesn't work with regular single quotes
	//$query = "INSERT INTO `users`(`name`, `email`, `password`) VALUE('Beth', 'beth@gmail.com', 'apples')";
	//mysqli_query($link, $query);
	
	// Use a backslash (\) to escape errors when typing certain characters
	// Example: to get O'Niel in a string ----> 'O\'Niel'
	//$query = "UPDATE `users` SET name='Ian O\'Neil' WHERE id=2 LIMIT 1";
	//mysqli_query($link, $query);
		
	// How to update existing data --->
	//$query = "UPDATE `users` SET `name`='Bethany' WHERE `name`='Beth'";
	//mysqli_query($link, $query);
	
	// * ---> everything
	// SELECT is a select query
	// surrounding selector with %% means anything can be before or after
	$name = "Ian O'Neil";
	$query = "SELECT `name` FROM users WHERE name='".mysqli_real_escape_string($link, $name)."'";
	
	// Checks if selector query worked
	if ($result=mysqli_query($link, $query)) {
		
		echo mysqli_num_rows($result);
		
		// Loop: fetches array from query
		// note: view source after printing to see info organized
		while ($row = mysqli_fetch_array($result)) {
			
			print_r($row);
			
		}
		
	} else {
		echo "It failed!";
	}
	

?>