<?php
	
	//set cookie id to '1234' and expiration to 1 day
	setcookie("id", "1234", time()+60*60*24);
	
	//expire cookie
	setcookie("id", "", time()-3600);
	
	echo $_COOKIE['id'];
	
?>