<?php
	
	//Level 1 security is storing regular passcodes on database
	
	
	//Level 2 uses a "HASH" function
	//password => '5f4dcc3b5aa765d61d8327deb882cf99' --> HACKED!!
	//more complicated hashes can't be hacked using crackstation.net
	// 
	//$password = "password"
	//echo md5($password);
	
	
	//Level 3 uses a "salt"
	//a salt variable consists of a random code consisting of letters and numbers
	//concoctinate the salt with the hash password
	//
	//$salt = "ilk56fd5d2p2d257a95d5";
	//echo md5($salt . $password);
	
	
	//Level 4 uses the hash of the hash of the users id concoctinated with the password
	//echo md5(md5($row['id']) . $password);
	
?>