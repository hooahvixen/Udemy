<?php

/*
* Plugin Name: Basic Plugin
* Plugin URI: http://176.32.230.249/olipresley.com/
* Description: Learning about Plugins
* Author: Rachel Presley
* Author URI: http://176.32.230.249/olipresley.com/
* Version: 1.0
* License: (License number)
*/

//  ^^^	Information for WordPress	^^^

/****For more info: codex.wordpress.org*****/


//	function your_function() {
//		do something
//	}
//	add_action('a_hook', '$your_function'...[Optional things-->] , $priority (default: 10), $accepted_args (default: 1));
//	OR^v
//	add_filter('a_hook', '$your_function'...[Optional things-->] , $priority (default: 10), $accepted_args (default: 1));

//  ^^^	Pattern	^^^

//	dwwp_ stands for "develop with wordpress" 
//	(It's a prefix, 
//	you need prefixes bc wordpress might have 
//	the same function name)

//	custom post type...refer to wp_job_listing.php
//	taxonomy goes hand in hand with custom post type
//	



//	include & require...links php files together

//	include 'file_name/path'; ... Will not give an 
//		error if file doesn't make it. This will 
//		load the plugin no matter what. Use for 
//		non-necessary files.

//	require 'file_name/path'; ... Will not load 
//		plugin AND WILL give you a fatal error 
//		message if the file does not load. Use 
//		for necessary files. (not the best practice)
//			Variation: require_once...
//			Tip: use: plugin_dir_path(__FILE__)...concactinate 
//				with file ...ensures that you always pull from 
//				the proper path.


?>