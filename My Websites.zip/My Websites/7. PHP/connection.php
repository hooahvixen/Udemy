<?php

$link = mysqli_connect("localhost", "cl57-example69", "RH/w9C2G-", "cl57-example69");

?>