<?php

/*
Plugin Name: My First Plugin
Plugin URI: http://176.32.230.249/olipresley.com/
Description: My learning plugin
Author: Rachel
version: 1.0
Author URI: http://176.32.230.249/olipresley.com/php/
*/

add_action('admin_menu', 'myfirstplugin_admin_actions');
function myfirstplugin_admin_actions() {
	add_options_page('MyFirstPlugin', 'MyFirstPlugin', 'manage_options', _FILE_, 'myfirstplugin_admin');
}
function myfirstplugin_admin() {
?>

<div class="wrap">
	<h2>This plugin will search the D</h2>
	<h3>This plugin will search the DB for all draft posts and display their Title and ID</h3>
	
	<p>Click the button below to begin the search</p>
	<br>
	<form action="" method="POST">
		<input type="submit" name="search_draft_posts" value="Search" class="button-primary" />
	</form>
	<br>
	
	<table class="widefat">
		<thead>
			<tr>
				<th>Post Title</th>
				<th>Post ID</th>
			</tr>
		</thead>
		<tfoot>
			<tr>
				<th>Post Title</th>
				<th>Post ID</th>
			</tr>
		</tfoot>
		<tbody>
<?php

	global $wpdb;
	$mytestdrafts = array();
	if(isset($_POST['search_draft_posts'])) {
		
		$mytestdrafts = $wpdb->get_results(
			"
			SELECT ID, post_title
			FROM $wpdb->posts
			WHERE post_status = 'draft'
			"
		);
		update_option('myfirstplugin_draft_posts', $mytestdrafts); //store the results in WP options table
	} else if (get_option('myfirstplugin_draft_posts')){
		$mytestdrafts = get_option('myfirstplugin_draft_posts');
	}
?>
<?php

	foreach ($mytestdrafts as $mytestdraft) {

?>
			<tr>
<?php

		echo "<td>".$mytestdraft->post_title."</td>";
		echo "<td>".$mytestdraft->post_ID."</td>";

?>
			</tr>
<?php
	}
?>
		</tbody>
	</table>
</div>

<?php
}
?>