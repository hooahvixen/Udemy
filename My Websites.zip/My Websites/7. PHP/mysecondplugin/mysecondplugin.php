<?php

/*
* Plugin Name: Basic Plugin
* Plugin URI: http://176.32.230.249/olipresley.com/
* Description: Learning about Plugins
* Author: Rachel Presley
* Author URI: http://176.32.230.249/olipresley.com/
* Version: 1.0
* License: (License number)
*/

//  ^^^	Information for WordPress	^^^

function dwwp_remove_dashboard_widget() {
	remove_meta_box('dashboard_primary', 'dashboard', 'side');
}
add_action('wp_dashboard_setup', 'dwwp_remove_dashboard_widget');

function add_google_link() {
	global $wp_admin_bar;

	//Add a link called 'My Link'...
	$wp_admin_bar->add_node(array(
		'id'    => 'google-analytics',
		'title' => 'Google Analytics',
		'href'  => 'http://www.google.com/analytics'
	));

}
add_action( 'wp_before_admin_bar_render', 'add_google_link' );
?>