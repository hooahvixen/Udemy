<?php
	
	$error;
	
	if ($_POST['submit']) {
		
		if (!$_POST['email']) $error.="<br>Please enter your email";
			else if (!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) $error.="<br>Please enter a valid email address!";
		
		if (!$_POST['password']) $error.="<br>Please, enter your password!";
			else {
				
				if (strlen($_POST['password'])<8) $error.="<br>Please, enter a password with at least 8 characters";
				if (preg_match('`[A-Z]`', $_POST['password'])) $error.="<br>Please, include at least one capital letter in your password";
				
			}
		
		if ($error) echo "Error(s): ".$error;
			else {
				
				$link = mysqli_connect("localhost", "cl57-example69", "RH/w9C2G-", "cl57-example69");
				if (mysqli_connect_error()) die("Could not connect to database");
				
				if ("SELECT `email` FROM users WHERE email='".$_POST["email"]"'") print_r "email already exists in our servers";
				
			}
	}
	
?>

<form method="post">
	
	<input type="email" name="email" id="email" />
	
	<input type="password" name="password" />
	
	<input type="submit" name="submit" value="Sign Up!" />
	
</form>