<?php

	$error;

	if ($_POST['submit']) {

		if (!$_POST['name']) {

			$error = "<br>Please, enter your name!";

		}

		if (!$_POST['email']) {

			$error .= "<br>Please, enter your Email!";

		}

		if ($_POST['email'] and !filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {

			$error .= "<br>Please, enter a valid Email address!";

		}

		if (!$_POST['comment']) {

			$error .= "<br>Please, leave a comment!";

		}

		if ($error) {

			$result = '<div class="alert alert-danger"><strong>There were error(s) in your form:'.$error.'</strong></div>';

		} else {

			if (mail("rachel@shebora.com", "Comment from Website!", "Name: ".$_POST['name']."
Email: ".$_POST['email']."
Comment: ".$_POST['comment'])) {

				$result = '<div class="alert alert-success"><strong>Success!</strong></div>';

			} else {

				$result = '<div class="alert alert-danger">Sorry! There was an error sending your message. Please try again later.</div>';

			}

		}

	}

?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Healing Arts Center</title>

    <link rel="shortcut icon" type="image/png" href="images/lotus2.png">

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
		<link href="css/index.css" rel="stylesheet">
  </head>
  <body>
    <div class="white">
      <nav class="navbar navbar-default background1 noMargin noBorder width1200">
  		  <div class="container">
  		    <!-- Brand and toggle get grouped for better mobile display -->
  		    <div class="navbar-header">
  		      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
  		        <span class="sr-only">Toggle navigation</span>
  		        <span class="icon-bar"></span>
  		        <span class="icon-bar"></span>
  		        <span class="icon-bar"></span>
  		      </button>
  		      <a class="navbar-brand" href="#"><img id="brand-img" src="images/lotus2.png" id="lotus" /><h1 class="noMargin color1" id="brand">Healing Arts Center</h1></a>
  		    </div>

  		    <!-- Collect the nav links, forms, and other content for toggling -->
  		    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
  		      <ul class="nav navbar-nav center">
  		        <li class="active"><a class="color1" href="#">Home<span class="sr-only">(current)</span></a></li>
  		        <li><a class="color1" href="staff.html">Staff</a></li>
              <li><a class="color1" href="#">Contact Us</a></li>
  		      </ul>
  		    </div><!-- /.navbar-collapse -->
  		  </div><!-- /.container-fluid -->
  		</nav>

      <div class="row">

    		<div class="container">

    			<div class="col-md-6 col-md-offset-3 emailForm">

    				<h1>My Email Form</h1>

    				<?php echo $result; ?>

    				<p class="lead">Please, fill out this form and I will get in touch with you as soon as possible</p>

    				<form method="post">

    					<div class="form=group">
    						<label for="name">Your Name:</label>
    						<input type='text' name="name" class="form-control" placeholder="Your Name" value="<?php echo $_POST['name'] ?>" />
    					</div>

    					<div class="form=group">
    						<label for="email">Your Email:</label>
    						<input type='email' name="email" class="form-control" placeholder="Your Email" value="<?php echo $_POST['email'] ?>" />
    					</div>

    					<div class="form=group">
    						<label for="comment">Your Comment:</label>
    						<textarea class="form-control" name="comment"><?php echo $_POST['comment'] ?></textarea>
    					</div>

    					<input name='submit' type="submit" class="btn btn-success btn-lg" value="Submit" />

    				</form>

    			</div>

    		</div>

    	</div>

      <footer class="footer width1200">

        <div class="container">

          <p class="col col-md-3 center color1 padding-top-15">
            Merchants Plaza
            2937 Route 611, Suite 10
            Tannersville, PA 18372
          </p>
          <p class="col col-md-6 color1 center padding-top-10">
            Healing Arts Center</br>
            <a href="http://healingartspa.com/index.html">www.healingartspa.com</a></br>
            <a href="http://www.rolfing-fascia.com/">www.Rolfing-Fascia.com</a>
          </p>
          <p class="col col-md-3 color1 center padding-top-15">
            (570)332-4365</br>
            <span>Vickiekovar@gmail.com</span>
          </p>

        </div>

      </footer>
    </div>
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>
