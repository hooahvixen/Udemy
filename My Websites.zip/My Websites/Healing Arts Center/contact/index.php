<?php>



</?>

<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
		<title>Bootstrap 101 Template</title>

		<!-- Bootstrap -->
		<link href="css/bootstrap.min.css" rel="stylesheet">

		<link href="https://fonts.googleapis.com/css?family=EB+Garamond" rel="stylesheet">

		<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
		<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
		<!--[if lt IE 9]>
		<script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
		<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
		<![endif]-->

		<style type="text/css">

			.reset-box-sizing,
			.reset-box-sizing *,
			.reset-box-sizing *:before,
			.reset-box-sizing *:after {
				-webkit-box-sizing: content-box;
				-moz-box-sizing: content-box;
				box-sizing: content-box;


			}

			body {
				font-family: 'EB Garamond', serif;
			}

			.navbar {
				border: none;
				border-radius: 0;
				background-color: #84a9b2;
			}
			.navbar-item {
				margin-top: 5px;
				font-size: 1.5em;
			}

			.pages {
				text-align: center;
			}

			.textRight {
				align: right;
			}

			.whitish {
				color: #f2efef;
			}

			a > #brand {
				font-size: 1.6em;
				padding: 1%;
				color: #f2efef;
			}

			#main-content{
				background-color: #B6C8CA;
				border-radius: 0;
				padding: 10%;
				text-align: center;
			}

			#bldg{
				width: 90%;
				border-radius: 1.5em;
			}

			.rowPadding{
				padding-top: 10%;
				padding-bottom: 10%;
				text-align: center;
				background-color: #DAE3EC;
			}

			.sidePadding-10 {
				padding-left: 10%;
				padding-right: 10%;
			}

			footer {
				text-align: center;
			}

			.row{
				margin-left: 0;
				margin-right: 0;
				margin-bottom: 10px;
			}
			.padding-15 {
				padding: 15px 0;
			}
			.dropdown{
				text-align: right;
			}

		</style>

	</head>
	<body>

		<div id="header" class="container-fluid">

			<nav class="navbar navbar-default">
				<div class="container-fluid">

					<!-- Brand and toggle get grouped for better mobile display -->
					<div class="col col-md-3 navbar-header">
						<button type="button" class="whitish navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
							<span class="sr-only">Toggle navigation</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>


							<a href="#"><div id="lotus" class="whitish nav navbar-nav"><img class="" src="images/lotus.png" /></div></a>
							<a href="#"><div id="brand" class="whitish nav navbar-nav">Healing Arts</br>Center</div></a>

					</div>

					<!-- Collect the nav links, forms, and other content for toggling -->
					<div class="collapse navbar-collapse">
						<ul class="nav navbar-nav col col-md-6">
							<li><a class="nav navbar-item pages" href="#home"><span class="whitish" >Home</span></a></li>
							<li><a class="nav navbar-item pages" href="#staff"><span class="whitish" >Staff</span></a></li>
							<li><a class="nav navbar-item pages" href="#directions"><span class="whitish" >Directions</span></a></li>
							<li><a class="nav navbar-item pages" href="#contactUs"><span class="whitish" >Contact Us</span></a></li>
							<li><a class="nav navbar-item pages" href="#"><span class="whitish" ></span></a></li>

						</ul>


						<ul class="nav navbar-nav navbar-right col col-md-3">
							<li class="dropdown">
								<a href="#" class="nav navbar-item dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><span class="whitish" >Staff</span></a>
								<ul class="dropdown-menu">
									<li ><a href="#" class="" >Placeholder</a></li>

									<li ><a href="#" class="" >Placeholder</a></li>
								</ul>
							</li>
						</ul>
					</div><!-- /.navbar-collapse -->
				</div><!-- /.container-fluid -->
			</nav>

		</div>

		<div id="main" class="container-fluid">

			<div id="main-content" class="jumbotron">

				<h1>Welcome</h1>

				<img id="bldg" src="images/building.jpg" />

				<p>The Lotus flower symbolizes  transformation  under all odds, the perfection of inner beauty remains unscathed.</p>

				<button class="btn btn-default">Learn More...</button>

			</div>

			<div id="xtr-content" class="row rowPadding">

				<div class="col-sm-6 sidePadding-10">

					<h2>Vickie Kovar</h2>

					<p>Something about Vickie</p>

				</div>

				<div class="col-sm-6 sidePadding-10">

					<h2>Tracey Alysson</h2>

					<p>Something about Tracey</p>

					<a href="#">Read More...</a>

				</div>

			</div>

		</div>

		<div id="footer" class="container-fluid">

			<footer class="footer">

				<div class="container">

					<p class="padding-15 col col-md-3 text-muted">
						Merchants Plaza
						2937 Route 611, Suite 10
						Tannersville, PA 18372
					</p>
					<p class="col col-md-6 text-muted">
						Healing Arts Center</br>
						<a href="http://healingartspa.com/index.html">www.healingartspa.com</a></br>
						<a href="http://www.rolfing-fascia.com/">www.Rolfing-Fascia.com</a>
					</p>
					<p class="padding-15 col col-md-3 text-muted">
						(570)332-4365</br>
						<span>Vickiekovar@gmail.com</span>
					</p>

				</div>

			</footer>

		</div>


		<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
		 <!-- Include all compiled plugins (below), or include individual files as needed -->
		<script src="js/bootstrap.min.js"></script>

	</body>
</html>
