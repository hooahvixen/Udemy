var clickedTime;
var creatTime;
var reactionTime;
var bestTime;
		
function random (a, b) {
	
	return Math.floor(Math.random() * (b - a + 1) + a);
	
}
		
function getRandomColor () {
	
	var letters = "0123456789ABCDEF".split('');
	var color = "#";
	for (var i = 0; i < 6; i++) {
		color += letters[Math.round(Math.random()*15)];
	}
	return color;
}
		
function makeBox() {
	
	setTimeout(function() {
	
		document.getElementById("box").style.display = "block";
		
		document.getElementById("box").style.backgroundColor = getRandomColor();
		
		document.getElementById("box").style.left = random(0,90) + "%";
		
		document.getElementById("box").style.top = random(0,90) + "%";
		
		document.getElementById("box").style.borderRadius = (random(0,1)*50) + "%";
		
		creatTime = Date.now();
		
	}, random(0, 3000));
	
}

document.getElementById("box").onclick = function () {
	
	clickedTime = Date.now();
	
	if (clickedTime) {
		reactionTime = (clickedTime - creatTime)/1000;
	}
	
	if (!bestTime) {
		bestTime = reactionTime;
	} else {
		if (reactionTime < bestTime) {
			bestTime = reactionTime;
		}
	}
	
	document.getElementById("time").innerHTML = reactionTime;
	
	document.getElementById("bestTime").innerHTML = bestTime;
	
	this.style.display = "none";
	
	makeBox();
		
}

document.getElementById("start").onclick = function() {
	
	makeBox();
	this.style.display = "none"
	
}
